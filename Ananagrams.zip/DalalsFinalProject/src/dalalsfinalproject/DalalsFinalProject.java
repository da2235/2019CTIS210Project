package dalalsfinalproject;

import javafx.scene.paint.Color;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class DalalsFinalProject extends Application {

    public TextArea wordInput;
    
    @Override
    public void start(Stage primaryStage) {

        LetterPane root = new LetterPane();
        ControlPane cPane = new ControlPane(root);

        Scene scene = new Scene(root, 1000, 800);

        primaryStage.setTitle("Anagrams");
        primaryStage.setScene(scene);
        primaryStage.show();

       
    }

    public static void main(String[] args) {
        launch(args);

    }

   
}
