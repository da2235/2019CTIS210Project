
package dalalsfinalproject;


import java.util.Random;
import javafx.scene.Group;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Letters extends StackPane {
   private Rectangle letterBackground;
   private String theLetter;
   private Text letterBox;
   private int x;
   private int y;
   private Font theFont;
   private int XMAX = 920;
   private int XMIN = 0;
   private int YMAX = 240;
   private int YMIN = 0;
   
   
    public Letters(String theLetter) {
          
        
        this.theLetter = theLetter;
        letterBox = new Text(this.theLetter);
        theFont = Font.font("Comic Sans", 40);
        letterBox.setFont(theFont);
        letterBackground = new Rectangle(75, 55, 
                Color.KHAKI);
        letterBackground.setStroke(Color.BLACK);
        letterBackground.setStrokeWidth(5);
        Random rand = new Random();
        x = rand.nextInt(XMAX);
        y = rand.nextInt(YMAX);
       
        getChildren().addAll(letterBackground, letterBox);
    }   

    public Rectangle getletterBackground() {
        return letterBackground;
    }

    public void setLetterBackground(Rectangle background) {
        this.letterBackground = background;
    }

    public String getTheLetter() {
        return theLetter;
    }

    public void setTheLetter(String theLetter) {
        this.theLetter = theLetter;
    }

    public Text getLetterdBox() {
        return letterBox;
    }

    public void setLetterBox(Text wordBox) {
        this.letterBox = letterBox;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
         if (x > XMAX) {
            this.x = XMAX;
        }
        else if (x < XMIN) {
            this.x = XMIN;
        }
        else {
            this.x = x;
        }
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    if (y > YMAX) {
            this.y = YMAX;
        } else if (y < YMIN) {
            this.y = YMIN;
        }
        else {
            this.y = y;
        }
    }
    
    
   
   
}
