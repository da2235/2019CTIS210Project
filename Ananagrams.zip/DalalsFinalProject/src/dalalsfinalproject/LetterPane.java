package dalalsfinalproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class LetterPane extends Pane {

    private ArrayList<String> wordList;
    private ArrayList<Letters> letterObjects;
    private int nLines;
    private int iLine;
    private Rectangle border1;
    private Rectangle border2;
    private Rectangle border3;
    private Font font1;
    private Font font2;
    private Font font3;
    
    
    public LetterPane() {

        Scanner fileScan = null;

        Rectangle border1 = new Rectangle(0, 0, 1000, 300);
        border1.setFill(null);
        border1.setStroke(Color.BLACK);
        border1.setStrokeWidth(5);
        Rectangle border2 = new Rectangle(0, 300, 610, 500);
        border2.setFill(null);
        border2.setStroke(Color.BLACK);
        border2.setStrokeWidth(5);
        Rectangle border3 = new Rectangle(610, 300, 390, 500);
        border3.setFill(null);
        border3.setStroke(Color.BLACK);
        border3.setStrokeWidth(5);
        Text text1 = new Text(250, 40, "Here are your letters!");
        font1 = new Font("Comic Sans", 50);
        text1.setFont(font1);
        Text text2 = new Text(50, 400, " \tEnter a list of \nthe words you find here");
        text2.setFont(font1);
     // font2 = new Font("Comic Sans", FontWeight.BOLD, 50);
        Text text3 = new Text(720, 400, "Scoring:");
        text3.setFont(font1);
        text3.setFill(Color.RED);
        Text text4 = new Text(700, 450, "After 60 seconds are up, count \nup your points:");
        font3 = new Font("Comic Sans", 20);
        text4.setFont(font3);
        text4.setFill(Color.ORANGE);
        Text text5 = new Text(700, 510, "~ 3 letter words = 30 points");
        text5.setFont(font3);
        text5.setFill(Color.GOLD);
        Text text6 = new Text(700, 540, "~ 4 letter words = 40 points");
        text6.setFont(font3);
        text6.setFill(Color.GREEN);
        Text text7 = new Text(700, 570, "~ 5 letter words = 50 points");
        text7.setFont(font3);
        text7.setFill(Color.BLUE);  
        Text text8 = new Text(700, 600, "~ 6 letter words = 60 points");
        text8.setFont(font3);
        text8.setFill(Color.PURPLE);
        
        
        getChildren().addAll(border1, border2, border3);
        getChildren().addAll(text1, text2, text3, text4, text5, text6, text7, text8);
        
        wordList = new ArrayList<String>();
        letterObjects = new ArrayList<Letters>();

        try {
            fileScan = new Scanner(new File("6LetterWords.txt"));
            //    fileScan.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(LetterPane.class.getName()).log(Level.SEVERE, null, ex);
        }

        Random rand = new Random();
        int nLines = rand.nextInt(500);

        int iLine = 0;
        while (iLine < nLines) {
            fileScan.nextLine();
            iLine = iLine + 1;
        }

        String word = fileScan.nextLine();
        wordList.add(word);

        for (char item : word.toCharArray()) {
            Letters currentWord = new Letters("" + item);
            letterObjects.add(currentWord);
            getChildren().add(currentWord);

        }

        for (Letters item : letterObjects) {

            item.setLayoutX(item.getX());
            item.setLayoutY(item.getY());

            item.setOnMouseDragged(this::processMouseDrag);
        }

    }

    public void processMouseDrag(MouseEvent event) {
        Letters source = (Letters) event.getSource();

        double newX = event.getSceneX();
        double newY = event.getSceneY();

        source.setX((int) newX);
        source.setY((int) newY);

        source.setLayoutX(source.getX());
        source.setLayoutY(source.getY());

    }

}
