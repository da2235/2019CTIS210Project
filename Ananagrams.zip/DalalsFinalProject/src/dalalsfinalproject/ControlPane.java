
package dalalsfinalproject;

import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class ControlPane {

    TextArea wordInput;
    LetterPane root;
 
    
    public ControlPane(LetterPane root) {
        this.root = root;
     
        wordInput = new TextArea("Words");
        wordInput.setLayoutX(5);
        wordInput.setLayoutY(500);
        
        root.getChildren().add(wordInput);
    }

    
}
